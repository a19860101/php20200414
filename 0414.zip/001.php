<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>HELLO PHP!!</h1>
    <?php
        $a = "HELLO!";//字串
        $b = 0.567;//數值
        $c = false;//布林 boolean
        //float 浮點數
        /*
            資料型態
            1.string 字串
            2.int 整數
            3.float 浮點數
            4.boolean 布林
        */
        // echo $c;
        var_dump($b);
    ?>
</body>
</html>